This directory contains data used to generate the Chip Explorer web application, but which is not part of our official
data release.
